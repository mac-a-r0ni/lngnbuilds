#ifndef _UTIL_H_
#define _UTIL_H_

void mbp_log(int level, const char *fmt, ...) __attribute__((format(printf, 2, 3)));

#endif
