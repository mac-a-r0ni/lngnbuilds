#include "minunit.h"

int main(int argc, char *argv[])
{
    (void)argc;
    tests(argv[0]);
}
